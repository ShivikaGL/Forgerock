﻿import { FRAuth, FRUser, Auth, FRLoginSuccess, Config, TokenManager, UserManager } from './index.js';
const FATAL = 'Fatal';
//import { FRStep } from './index.js'

let step = {
    error: undefined,
    ssoToken: undefined,
    step: undefined
};

Config.set({
    clientId: 'PayDashboard',
    redirectUri: window.location.origin + '/login',
    scope: 'openid profile email address phone roles',
    serverConfig: {
        baseUrl: 'https://openam-experianpdb-euw2-dev.id.forgerock.io/am',
        timeout: 5000,
    },
    realmPath: 'bravo',
    tree: 'UserAuthentication',

});

// Define custom handlers to render and submit each expected step
const handlers = {
    UsernamePassword: (step) => {
        const panel = document.getElementById('login-button');
        $("form").submit(function (e) {
            e.preventDefault();
            return false;
        });
        panel.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            let userEmail = document.getElementById('Email').value;
            let userPassword = document.getElementById('Password').value;
            const nameCallback = step.getCallbackOfType('NameCallback');
            const passwordCallback = step.getCallbackOfType('PasswordCallback');
            nameCallback.setName(userEmail);
            passwordCallback.setPassword(userPassword);
            nextStep(step);
        });
    },
    Error: (step) => {
        document.querySelector('#Error span').innerHTML = step.getCode();
    },
    [FATAL]: (step) => { },
};

// Show only the view for this handler
const showStep = (handler) => {
    document.querySelectorAll('#steps > div').forEach((x) => x.classList.remove('active'));
    return true;
};

const showUser = (user, tokenid, realm, successUrl, accessToken) => {
    const resp = { "user": user, "realm": realm, "successurl": successUrl, "tokenid": tokenid }
    if (tokenid != "") {

        setCookie("accesstoken", accessToken, 1, window.location.host);
        window.location.href = `${window.location.origin}/login-mfa`;
        
    }
    
    showStep('User');
};

const getStage = (step) => {
    // Check if the step contains callbacks for capturing username and password
    const usernameCallbacks = step.getCallbacksOfType('NameCallback');
    const passwordCallbacks = step.getCallbacksOfType('PasswordCallback');

    if (usernameCallbacks.length && passwordCallbacks.length) {
        return 'UsernamePassword';
    }

    return undefined;
};

// Display and bind the handler for this stage
const handleStep = async (step) => {

    switch (step.type) {
        case 'LoginSuccess': {
            // If we have a session token, get user information
            //alert("success");
            const sessionToken = step.getSessionToken();
            const realm = step.getRealm();
            const successUrl = step.getSuccessUrl();
            const tokens = await TokenManager.getTokens();
            //const idToken = tokens.idToken;
            console.log("access token :" + tokens.accessToken);
            console.log("tokens : " + tokens.idToken);
            console.log("tokens expiry : " + tokens.tokenExpiry);
            const cookieVal = JSON.stringify(tokens);
            setCookie("FR-SDK-PayDashboard", cookieVal, 1, window.location.hostname);
            const user = await UserManager.getCurrentUser();
            return showUser(user, sessionToken, realm, successUrl, tokens.accessToken);
            window.location.href = `${window.location.origin}/login-mfa`;
        }

        case 'LoginFailure': {
            showStep('Error');
            handlers['Error'](step);
            alert('fail');
            return;
        }

        default: {
            const stage = getStage(step) || FATAL;
            console.log(showStep(stage), "==== show step stage ====");
            console.log(stage, "====stage ======")
            if (!showStep(stage)) {
                showStep(FATAL);
                handlers[FATAL](step);
            } else {
                handlers[stage](step);
            }
        }

    }
};

const handleFatalError = (err) => {

    console.error('Fatal error', err);
    // alert("Exception");
    showStep(FATAL);
};


const onError = (error) => {
    console.log(error);
}
 //Get the next step using the FRAuth API
const nextStep = async (step) => {
    step = await FRAuth.next(step).catch(onError);
    console.log(step, "step at end of nextstep");
        await handleStep(step);
    
    
};

//const nextStep = (step) => {
//     FRAuth.next(step).then(handleStep).catch(handleFatalError);
//};

const logout = async () => {
    try {
        await FRUser.logout();
        location.reload();
    } catch (error) {
        console.error(error);
    }
};

const setCookie = (name, value, days, domain) => {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + ";domain=" + domain + "; path=/";
};

nextStep();


