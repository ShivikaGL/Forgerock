﻿import { FRAuth, FRUser, Config, TokenManager, UserManager } from './index.js';
const FATAL = 'Fatal';

Config.set({
    clientId: 'PayDashboard',
    redirectUri: window.location.origin + '/login',
    scope: 'openid profile email address phone roles',
    serverConfig: {
        baseUrl: 'https://openam-experianpdb-euw2-dev.id.forgerock.io/am',
        timeout: 5000,
    },
    realmPath: 'bravo',
    tree: 'PasswordReset',

});

var step = {

}
// Define custom handlers to render and submit each expected step
const handlers = {
    ValidatedCreatePasswordCallback: (step) => {
        const panel = document.getElementById('resetPasswordButtonId');
        $("form").submit(function (e) {
            e.preventDefault();
            return false;
        });
        panel.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log("== === === ==== insdie valdiate create password callback === ===== ====== ===");
            let userEmailForResettingPassword = document.getElementById("Password").value;
            const resetPasswordCallback = step.getCallbackOfType("ValidatedCreatePasswordCallback");
            resetPasswordCallback.setPassword(userEmailForResettingPassword);
            nextStep(step);
        });
    },
    Error: (step) => {
        document.querySelector('#Error span').innerHTML = step.getCode();
    },
    [FATAL]: (step) => handleFatalError(),
};


const sendEmail = async (step) => {
    await FRAuth.next(step).catch(onError);
}

const getStage = (step) => {
    // Check if the step contains callbacks for capturing username and password
    const validatedCreatePasswordCallback = step.getCallbacksOfType('ValidatedCreatePasswordCallback');
    if (validatedCreatePasswordCallback.length > 0) {
        return "ValidatedCreatePasswordCallback";
    } else {
        sendEmail(step);
        return undefined;
    }
};

// Display and bind the handler for this stage
const handleStep = async (step) => {

    switch (step.type) {
        default: {
            const stage = getStage(step) || FATAL;
            handlers[stage](step);
        }
    }
};

const handleFatalError = (err) => {

    console.error('Fatal error', err);
    // alert("Exception");
};


const onError = (error) => {
    console.log(error);
}
// Get the next step using the FRAuth API
const nextStep = async (step) => {
    step = await FRAuth.next(step).catch(onError);
    await handleStep(step);
};

window.onload = function () {
    step = JSON.parse(sessionStorage.getItem('ValidatedCreatePasswordCallback'));
    nextStep(step);
}

//nextStep();




