import { PREFIX } from '../config/constants.js';

/*
 * @forgerock/javascript-sdk
 *
 * local-storage.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Provides wrapper for tokens with localStorage.
 */
class LocalStorageWrapper {
    /**
     * Retrieve tokens.
     */
    static async get(clientId) {
        const tokenString = localStorage.getItem(`${PREFIX}-${clientId}`);
        // If there is no stored token, or the token is not an object, return null
        if (!tokenString) {
            // This is a normal state, so resolve with undefined
            return;
        }
        try {
            return JSON.parse(tokenString || '');
        }
        catch (err) {
            // This is an error state, so reject
            throw new Error('Could not parse token object from localStorage');
        }
    }
    /**
     * Saves tokens.
     */
    static async set(clientId, tokens) {
        const tokenString = JSON.stringify(tokens);
        localStorage.setItem(`${PREFIX}-${clientId}`, tokenString);
    }
    /**
     * Removes stored tokens.
     */
    static async remove(clientId) {
        localStorage.removeItem(`${PREFIX}-${clientId}`);
    }
}

export { LocalStorageWrapper as default };
