import { PREFIX } from '../config/constants.js';

/*
 * @forgerock/javascript-sdk
 *
 * session-storage.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Provides wrapper for tokens with sessionStorage.
 */
class SessionStorageWrapper {
    /**
     * Retrieve tokens.
     */
    static async get(clientId) {
        const tokenString = sessionStorage.getItem(`${PREFIX}-${clientId}`);
        // If there is no stored token, or the token is not an object, return null
        if (!tokenString) {
            // This is a normal state, so resolve with undefined
            return;
        }
        try {
            return JSON.parse(tokenString || '');
        }
        catch (err) {
            // This is an error state, so reject
            throw new Error('Could not parse token from sessionStorage');
        }
    }
    /**
     * Saves tokens.
     */
    static async set(clientId, tokens) {
        const tokenString = JSON.stringify(tokens);
        sessionStorage.setItem(`${PREFIX}-${clientId}`, tokenString);
    }
    /**
     * Removes stored tokens.
     */
    static async remove(clientId) {
        sessionStorage.removeItem(`${PREFIX}-${clientId}`);
    }
}

export { SessionStorageWrapper as default };
