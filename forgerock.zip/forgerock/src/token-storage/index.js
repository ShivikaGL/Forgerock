import Config from '../config/index.js';
import { FRLogger } from '../util/logger.js';
import LocalStorageWrapper from './local-storage.js';
import SessionStorageWrapper from './session-storage.js';

/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020-2021 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Provides access to the token storage API.
 * The type of storage (localStorage, sessionStorage, etc) can be configured
 * through `tokenStore` object on the SDK configuration.
 */
class TokenStorage {
    /**
     * Gets stored tokens.
     */
    static async get() {
        const { clientId, tokenStore } = this.getClientConfig();
        if (tokenStore === 'sessionStorage') {
            return await SessionStorageWrapper.get(clientId);
        }
        else if (tokenStore === 'localStorage') {
            return await LocalStorageWrapper.get(clientId);
            // Preserving this condition for communicating its removal
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
        }
        else if (tokenStore === 'indexedDB') {
            FRLogger.warn('IndexedDB is not supported in this version.');
        }
        else if (tokenStore && tokenStore.get) {
            // User supplied token store
            return await tokenStore.get(clientId);
        }
        return await LocalStorageWrapper.get(clientId);
    }
    /**
     * Saves tokens.
     */
    static async set(tokens) {
        const { clientId, tokenStore } = this.getClientConfig();
        if (tokenStore === 'sessionStorage') {
            return await SessionStorageWrapper.set(clientId, tokens);
        }
        else if (tokenStore === 'localStorage') {
            return await LocalStorageWrapper.set(clientId, tokens);
            // Preserving this condition for communicating its removal
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
        }
        else if (tokenStore === 'indexedDB') {
            FRLogger.warn('IndexedDB is not supported in this version.');
        }
        else if (tokenStore && tokenStore.set) {
            // User supplied token store
            return await tokenStore.set(clientId, tokens);
        }
        return await LocalStorageWrapper.set(clientId, tokens);
    }
    /**
     * Removes stored tokens.
     */
    static async remove() {
        const { clientId, tokenStore } = this.getClientConfig();
        if (tokenStore === 'sessionStorage') {
            return await SessionStorageWrapper.remove(clientId);
        }
        else if (tokenStore === 'localStorage') {
            return await LocalStorageWrapper.remove(clientId);
            // Preserving this condition for communicating its removal
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
        }
        else if (tokenStore === 'indexedDB') {
            FRLogger.warn('IndexedDB is not supported in this version.');
        }
        else if (tokenStore && tokenStore.remove) {
            // User supplied token store
            return await tokenStore.remove(clientId);
        }
        return await LocalStorageWrapper.remove(clientId);
    }
    static getClientConfig() {
        const { clientId = 'unconfiguredClient', tokenStore = 'localStorage' } = Config.get();
        return { clientId, tokenStore };
    }
}

export { TokenStorage as default };
