import Config from '../config/index.js';
import { REQUESTED_WITH } from '../shared/constants.js';
import { isOkOr4xx } from '../util/http.js';
import { withTimeout } from '../util/timeout.js';
import { ActionTypes } from '../config/enums.js';
import middlewareWrapper from '../util/middleware.js';
import { getEndpointPath, resolve } from '../util/url.js';

/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Provides access to the session management API.
 */
class SessionManager {
    /**
     * Ends the current session.
     */
    static async logout(options) {
        const { middleware, realmPath, serverConfig } = Config.get(options);
        const init = {
            credentials: 'include',
            headers: new Headers({
                'Accept-API-Version': 'protocol=1.0,resource=2.0',
                'X-Requested-With': REQUESTED_WITH,
            }),
            method: 'POST',
        };
        const path = `${getEndpointPath('sessions', realmPath, serverConfig.paths)}?_action=logout`;
        const url = resolve(serverConfig.baseUrl, path);
        const runMiddleware = middlewareWrapper({ url: new URL(url), init }, { type: ActionTypes.Logout });
        const req = runMiddleware(middleware);
        const response = await withTimeout(fetch(req.url.toString(), req.init), serverConfig.timeout);
        if (!isOkOr4xx(response)) {
            throw new Error(`Failed to log out; received ${response.status}`);
        }
        return response;
    }
}

export { SessionManager as default };
