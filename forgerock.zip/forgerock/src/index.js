/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020-2021 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */

import Auth from "./auth/index.js"
import { CallbackType, ErrorCode } from "./auth/enums.js"
import Config from "./config/index.js"
import FRAuth from "./fr-auth/index.js"
import FRCallback from "./fr-auth/callbacks/index.js"
import AttributeInputCallback from "./fr-auth/callbacks/attribute-input-callback.js"
import ChoiceCallback from "./fr-auth/callbacks/choice-callback.js"
import ConfirmationCallback from "./fr-auth/callbacks/confirmation-callback.js"
import DeviceProfileCallback from "./fr-auth/callbacks/device-profile-callback.js"
import HiddenValueCallback from "./fr-auth/callbacks/hidden-value-callback.js"
import KbaCreateCallback from "./fr-auth/callbacks/kba-create-callback.js"
import MetadataCallback from "./fr-auth/callbacks/metadata-callback.js"
import NameCallback from "./fr-auth/callbacks/name-callback.js"
import PasswordCallback from "./fr-auth/callbacks/password-callback.js"
import PollingWaitCallback from "./fr-auth/callbacks/polling-wait-callback.js"
import ReCaptchaCallback from "./fr-auth/callbacks/recaptcha-callback.js"
import RedirectCallback from "./fr-auth/callbacks/redirect-callback.js"
import SelectIdPCallback from "./fr-auth/callbacks/select-idp-callback.js"
import SuspendedTextOutputCallback from "./fr-auth/callbacks/suspended-text-output-callback.js"
import TermsAndConditionsCallback from "./fr-auth/callbacks/terms-and-conditions-callback.js"
import TextInputCallback from "./fr-auth/callbacks/text-input-callback.js"
import TextOutputCallback from "./fr-auth/callbacks/text-output-callback.js"
// eslint-disable-next-line max-len
import ValidatedCreatePasswordCallback from "./fr-auth/callbacks/validated-create-password-callback.js"
// eslint-disable-next-line max-len
import ValidatedCreateUsernameCallback from "./fr-auth/callbacks/validated-create-username-callback.js"
import { StepType } from "./fr-auth/enums.js"
import FRLoginFailure from "./fr-auth/fr-login-failure.js"
import FRLoginSuccess from "./fr-auth/fr-login-success.js"
import FRStep from "./fr-auth/fr-step.js"
import FRDevice from "./fr-device/index.js"
import FRPolicy, { PolicyKey } from "./fr-policy/index.js"
import FRQRCode from "./fr-qr-code/index.js"
import defaultMessageCreator from "./fr-policy/message-creator.js"
import FRRecoveryCodes from "./fr-recovery-codes/index.js"
import FRUser from "./fr-user/index.js"
import FRWebAuthn, { WebAuthnOutcome, WebAuthnStepType } from "./fr-webauthn/index.js"
import HttpClient from "./http-client/index.js"
import OAuth2Client, { ResponseType } from "./oauth2-client/index.js"
import SessionManager from "./session-manager/index.js"
import TokenManager from "./token-manager/index.js"
import TokenStorage from "./token-storage/index.js"
import UserManager from "./user-manager/index.js"
import Deferred from "./util/deferred.js"
import PKCE from "./util/pkce.js"
import LocalStorage from "./util/storage.js"
export {
    defaultMessageCreator,
    AttributeInputCallback,
    Auth,
    CallbackType,
    ChoiceCallback,
    Config,
    ConfirmationCallback,
    Deferred,
    DeviceProfileCallback,
    ErrorCode,
    FRAuth,
    FRCallback,
    FRDevice,
    FRLoginFailure,
    FRLoginSuccess,
    FRPolicy,
    FRQRCode,
    FRRecoveryCodes,
    FRStep,
    FRUser,
    FRWebAuthn,
    HiddenValueCallback,
    HttpClient,
    KbaCreateCallback,
    LocalStorage,
    MetadataCallback,
    NameCallback,
    OAuth2Client,
    PasswordCallback,
    PKCE,
    PolicyKey,
    PollingWaitCallback,
    ReCaptchaCallback,
    RedirectCallback,
    ResponseType,
    SelectIdPCallback,
    SessionManager,
    StepType,
    SuspendedTextOutputCallback,
    TermsAndConditionsCallback,
    TextInputCallback,
    TextOutputCallback,
    TokenManager,
    TokenStorage,
    UserManager,
    ValidatedCreatePasswordCallback,
    ValidatedCreateUsernameCallback,
    WebAuthnOutcome,
    WebAuthnStepType
}
