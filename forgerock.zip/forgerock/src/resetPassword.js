﻿import { FRAuth, FRUser, Config, TokenManager, UserManager } from './index.js';
const FATAL = 'Fatal';

let step = {
    error: undefined,
    ssoToken: undefined,
    step: undefined
};

Config.set({
    clientId: 'PayDashboard',
    redirectUri: window.location.origin + '/login',
    scope: 'openid profile email address phone roles',
    serverConfig: {
        baseUrl: 'https://openam-experianpdb-euw2-dev.id.forgerock.io/am',
        timeout: 5000,
    },
    realmPath: 'bravo',
    tree: 'PasswordReset',

});


// Define custom handlers to render and submit each expected step
const handlers = {
    StringAttributeInputCallback: (step) => {
        const panel = document.getElementById('resetPassword');
        $("form").submit(function (e) {
            e.preventDefault();
            return false;
        });
        panel.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            let userEmailForResettingPassword = document.getElementById("ForgotPasswordEmail").value;
            const resetPasswordCallback = step.getCallbackOfType('StringAttributeInputCallback');
            resetPasswordCallback.setValue(userEmailForResettingPassword);
            nextStep(step);
        });
    },
    PasswordCallback: (step) => {
        sessionStorage.setItem("PasswordCallback", JSON.stringify(step));
        window.location.href = `${window.location.origin}/MFAThroughSMS`;
        console.log("=== === === === =Inside sespendedTextOutputCallBack === === ===password input callback === ====", step)
    },
    Error: (step) => {
        document.querySelector('#Error span').innerHTML = step.getCode();
    },
    [FATAL]: (step) => { },
};

// Show only the view for this handler
const showStep = (handler) => {
    document.querySelectorAll('#steps > div').forEach((x) => x.classList.remove('active'));
    return true;
};

const showUser = (user, tokenid, realm, successUrl) => {
    const resp = { "user": user, "realm": realm, "successurl": successUrl, "tokenid": tokenid }
    window.location.href = `${window.location.origin}/login-mfa`;
    setCookie("2d44ba1f0633676", tokenid, 1, "localhost")
    showStep('User');
};

const getStage = (step) => {
    // Check if the step contains callbacks for capturing username and password
    let userEmailForResettingPassword = document.getElementById("ForgotPasswordEmail").value;
    if (step.callbacks[0].payload.type == "PasswordCallback") {
        return "PasswordCallback"
    } else if (userEmailForResettingPassword.length > 0) {
        return 'StringAttributeInputCallback';
    }

    return undefined;
};

// Display and bind the handler for this stage
const handleStep = async (step) => {

    switch (step.type) {
        case 'LoginSuccess': {
            // If we have a session token, get user information
            //alert("success");
            const sessionToken = step.getSessionToken();
            const realm = step.getRealm();
            const successUrl = step.getSuccessUrl();
            const tokens = await TokenManager.getTokens();
            //const idToken = tokens.idToken;
            console.log("access token :" + tokens.accessToken);
            console.log("tokens : " + tokens.idToken);
            console.log("tokens expiry : " + tokens.tokenExpiry);
            const user = await UserManager.getCurrentUser();
            return showUser(user, sessionToken, realm, successUrl);
        }

        case 'LoginFailure': {
            showStep('Error');
            handlers['Error'](step);
            alert('fail');
            return;
        }

        default: {
            const stage = getStage(step) || FATAL;
            console.log(showStep(stage), "==== show step stage ====");
            console.log(stage, "====stage ======")
            if (!showStep(stage)) {
                showStep(FATAL);
                handlers[FATAL](step);
            } else {

                console.log("=== === stage before calling handlers inside else=== ==== ===", stage);
                handlers[stage](step);
            }
        }
    }
};

const handleFatalError = (err) => {

    console.error('Fatal error', err);
    // alert("Exception");
    showStep(FATAL);
};


const onError = (error) => {
    console.log(error);
}
// Get the next step using the FRAuth API
const nextStep = async (step) => {

    step = await FRAuth.next(step).catch(onError);
    console.log(step, "step at end of nextstep");
    await handleStep(step);
};

const logout = async () => {
    try {
        await FRUser.logout();
        location.reload();
    } catch (error) {
        console.error(error);
    }
};

const setCookie = (name, value, days, domain) => {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + ";domain=" + domain + "; path=/";
};

nextStep();

