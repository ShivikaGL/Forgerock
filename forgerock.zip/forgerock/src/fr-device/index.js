import { fontNames, devicePlatforms, displayProps, browserProps, hardwareProps, platformProps, configurableCategories, delay } from './defaults.js';
import Collector from './collector.js';
import { PREFIX } from '../config/constants.js';
import { FRLogger } from '../util/logger.js';

/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * @class FRDevice - Collects user device metadata
 *
 * Example:
 *
 * ```js
 * // Instantiate new device object (w/optional config, if needed)
 * const device = new forgerock.FRDevice(
 *   // optional configuration
 * );
 * // override any instance methods, if needed
 * // e.g.: device.getDisplayMeta = () => {};
 *
 * // Call getProfile with required argument obj of boolean properties
 * // of location and metadata
 * const profile = await device.getProfile({
 *   location: isLocationRequired,
 *   metadata: isMetadataRequired,
 * });
 * ```
 */
class FRDevice extends Collector {
    constructor(config) {
        super();
        this.config = {
            fontNames,
            devicePlatforms,
            displayProps,
            browserProps,
            hardwareProps,
            platformProps,
        };
        if (config) {
            Object.keys(config).forEach((key) => {
                if (!configurableCategories.includes(key)) {
                    throw new Error('Device profile configuration category does not exist.');
                }
                this.config[key] = config[key];
            });
        }
    }
    getBrowserMeta() {
        if (typeof navigator === 'undefined') {
            FRLogger.warn('Cannot collect browser metadata. navigator is not defined.');
            return {};
        }
        return this.reduceToObject(this.config.browserProps, navigator);
    }
    getBrowserPluginsNames() {
        if (!(typeof navigator !== 'undefined' && navigator.plugins)) {
            FRLogger.warn('Cannot collect browser plugin information. navigator.plugins is not defined.');
            return '';
        }
        return this.reduceToString(Object.keys(navigator.plugins), navigator.plugins);
    }
    getDeviceName() {
        if (typeof navigator === 'undefined') {
            FRLogger.warn('Cannot collect device name. navigator is not defined.');
            return '';
        }
        const userAgent = navigator.userAgent;
        const platform = navigator.platform;
        switch (true) {
            case this.config.devicePlatforms.mac.includes(platform):
                return 'Mac (Browser)';
            case this.config.devicePlatforms.ios.includes(platform):
                return `${platform} (Browser)`;
            case this.config.devicePlatforms.windows.includes(platform):
                return 'Windows (Browser)';
            case /Android/.test(platform) || /Android/.test(userAgent):
                return 'Android (Browser)';
            case /CrOS/.test(userAgent) || /Chromebook/.test(userAgent):
                return 'Chrome OS (Browser)';
            case /Linux/.test(platform):
                return 'Linux (Browser)';
            default:
                return `${platform || 'Unknown'} (Browser)`;
        }
    }
    getDisplayMeta() {
        if (typeof screen === 'undefined') {
            FRLogger.warn('Cannot collect screen information. screen is not defined.');
            return {};
        }
        return this.reduceToObject(this.config.displayProps, screen);
    }
    getHardwareMeta() {
        if (typeof navigator === 'undefined') {
            FRLogger.warn('Cannot collect OS metadata. Navigator is not defined.');
            return {};
        }
        return this.reduceToObject(this.config.hardwareProps, navigator);
    }
    getIdentifier() {
        const storageKey = `${PREFIX}-DeviceID`;
        if (!(typeof globalThis.crypto !== 'undefined' && globalThis.crypto.getRandomValues)) {
            FRLogger.warn('Cannot generate profile ID. Crypto and/or getRandomValues is not supported.');
            return '';
        }
        if (!localStorage) {
            FRLogger.warn('Cannot store profile ID. localStorage is not supported.');
            return '';
        }
        let id = localStorage.getItem(storageKey);
        if (!id) {
            // generate ID, 3 sections of random numbers: "714524572-2799534390-3707617532"
            id = globalThis.crypto.getRandomValues(new Uint32Array(3)).join('-');
            localStorage.setItem(storageKey, id);
        }
        return id;
    }
    getInstalledFonts() {
        if (typeof document === undefined) {
            FRLogger.warn('Cannot collect font data. Global document object is undefined.');
            return '';
        }
        const canvas = document.createElement('canvas');
        if (!canvas) {
            FRLogger.warn('Cannot collect font data. Browser does not support canvas element');
            return '';
        }
        const context = canvas.getContext && canvas.getContext('2d');
        if (!context) {
            FRLogger.warn('Cannot collect font data. Browser does not support 2d canvas context');
            return '';
        }
        const text = 'abcdefghi0123456789';
        context.font = '72px Comic Sans';
        const baseWidth = context.measureText(text).width;
        const installedFonts = this.config.fontNames.reduce((prev, curr) => {
            context.font = `72px ${curr}, Comic Sans`;
            const newWidth = context.measureText(text).width;
            if (newWidth !== baseWidth) {
                prev = `${prev}${curr};`;
            }
            return prev;
        }, '');
        return installedFonts;
    }
    async getLocationCoordinates() {
        if (!(typeof navigator !== 'undefined' && navigator.geolocation)) {
            FRLogger.warn('Cannot collect geolocation information. navigator.geolocation is not defined.');
            return Promise.resolve({});
        }
        // eslint-disable-next-line no-async-promise-executor
        return new Promise(async (resolve) => {
            navigator.geolocation.getCurrentPosition((position) => resolve({
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
            }), (error) => {
                FRLogger.warn('Cannot collect geolocation information. ' + error.code + ': ' + error.message);
                resolve({});
            }, {
                enableHighAccuracy: true,
                timeout: delay,
                maximumAge: 0,
            });
        });
    }
    getOSMeta() {
        if (typeof navigator === 'undefined') {
            FRLogger.warn('Cannot collect OS metadata. navigator is not defined.');
            return {};
        }
        return this.reduceToObject(this.config.platformProps, navigator);
    }
    async getProfile({ location, metadata }) {
        const profile = {
            identifier: this.getIdentifier(),
        };
        if (metadata) {
            profile.metadata = {
                hardware: {
                    ...this.getHardwareMeta(),
                    display: this.getDisplayMeta(),
                },
                browser: {
                    ...this.getBrowserMeta(),
                    plugins: this.getBrowserPluginsNames(),
                },
                platform: {
                    ...this.getOSMeta(),
                    deviceName: this.getDeviceName(),
                    fonts: this.getInstalledFonts(),
                    timezone: this.getTimezoneOffset(),
                },
            };
        }
        if (location) {
            profile.location = await this.getLocationCoordinates();
        }
        return profile;
    }
    getTimezoneOffset() {
        try {
            return new Date().getTimezoneOffset();
        }
        catch (err) {
            FRLogger.warn('Cannot collect timezone information. getTimezoneOffset is not defined.');
            return null;
        }
    }
}

export { FRDevice as default };
