import { plural } from '../util/strings.js';
import { PolicyKey } from './enums.js';
import { getProp } from './helpers.js';

/*
 * @forgerock/javascript-sdk
 *
 * message-creator.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
const defaultMessageCreator = {
    [PolicyKey.CannotContainCharacters]: (property, params) => {
        const forbiddenChars = getProp(params, 'forbiddenChars', '');
        return `${property} must not contain following characters: "${forbiddenChars}"`;
    },
    [PolicyKey.CannotContainDuplicates]: (property, params) => {
        const duplicateValue = getProp(params, 'duplicateValue', '');
        return `${property}  must not contain duplicates: "${duplicateValue}"`;
    },
    [PolicyKey.CannotContainOthers]: (property, params) => {
        const disallowedFields = getProp(params, 'disallowedFields', '');
        return `${property} must not contain: "${disallowedFields}"`;
    },
    [PolicyKey.LeastCapitalLetters]: (property, params) => {
        const numCaps = getProp(params, 'numCaps', 0);
        return `${property} must contain at least ${numCaps} capital ${plural(numCaps, 'letter')}`;
    },
    [PolicyKey.LeastNumbers]: (property, params) => {
        const numNums = getProp(params, 'numNums', 0);
        return `${property} must contain at least ${numNums} numeric ${plural(numNums, 'value')}`;
    },
    [PolicyKey.MatchRegexp]: (property) => `${property} has failed the "MATCH_REGEXP" policy`,
    [PolicyKey.MaximumLength]: (property, params) => {
        const maxLength = getProp(params, 'maxLength', 0);
        return `${property} must be at most ${maxLength} ${plural(maxLength, 'character')}`;
    },
    [PolicyKey.MaximumNumber]: (property) => `${property} has failed the "MAXIMUM_NUMBER_VALUE" policy`,
    [PolicyKey.MinimumLength]: (property, params) => {
        const minLength = getProp(params, 'minLength', 0);
        return `${property} must be at least ${minLength} ${plural(minLength, 'character')}`;
    },
    [PolicyKey.MinimumNumber]: (property) => `${property} has failed the "MINIMUM_NUMBER_VALUE" policy`,
    [PolicyKey.Required]: (property) => `${property} is required`,
    [PolicyKey.Unique]: (property) => `${property} must be unique`,
    [PolicyKey.UnknownPolicy]: (property, params) => {
        const policyRequirement = getProp(params, 'policyRequirement', 'Unknown');
        return `${property}: Unknown policy requirement "${policyRequirement}"`;
    },
    [PolicyKey.ValidArrayItems]: (property) => `${property} has failed the "VALID_ARRAY_ITEMS" policy`,
    [PolicyKey.ValidDate]: (property) => `${property} has an invalid date`,
    [PolicyKey.ValidEmailAddress]: (property) => `${property} has an invalid email address`,
    [PolicyKey.ValidNameFormat]: (property) => `${property} has an invalid name format`,
    [PolicyKey.ValidNumber]: (property) => `${property} has an invalid number`,
    [PolicyKey.ValidPhoneFormat]: (property) => `${property} has an invalid phone number`,
    [PolicyKey.ValidQueryFilter]: (property) => `${property} has failed the "VALID_QUERY_FILTER" policy`,
    [PolicyKey.ValidType]: (property) => `${property} has failed the "VALID_TYPE" policy`,
};

export { defaultMessageCreator as default };
