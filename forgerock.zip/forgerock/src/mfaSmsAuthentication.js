﻿import { FRAuth, FRUser, Config, TokenManager, UserManager } from './index.js';
const FATAL = 'Fatal';

Config.set({
    clientId: 'PayDashboard',
    redirectUri: window.location.origin + '/login',
    scope: 'openid profile email address phone roles',
    serverConfig: {
        baseUrl: 'https://openam-experianpdb-euw2-dev.id.forgerock.io/am',
        timeout: 5000,
    },
    realmPath: 'bravo',
    tree: 'PasswordReset',

});

var step = {

}
// Define custom handlers to render and submit each expected step
const handlers = {
    PasswordCallback: (step) => {
        const panel = document.getElementById('enterOptButton');
        $("form").submit(function (e) {
            e.preventDefault();
            return false;
        });
        panel.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            let userEmailForResettingPassword = document.getElementById("enterOtpInput").value;
            const resetPasswordCallback = step.getCallbackOfType("PasswordCallback");
            resetPasswordCallback.setPassword(userEmailForResettingPassword);
            nextStep(step);
        });
    },
    ValidatedCreatePasswordCallback: (step) => {
        sessionStorage.setItem("ValidatedCreatePasswordCallback", JSON.stringify(step));
        window.location.href = `${window.location.origin}/reset-password`;
    },
    Error: (step) => {
        document.querySelector('#Error span').innerHTML = step.getCode();
    },
    [FATAL]: (step) => { },
};


const getStage = (step) => {
    if (step.callbacks[0].payload.type == "PasswordCallback") {
        return "PasswordCallback"
    } else if (step.callbacks[0].payload.type == "ValidatedCreatePasswordCallback") {
        return 'ValidatedCreatePasswordCallback';
    }
};

// Display and bind the handler for this stage
const handleStep = async (step) => {

    switch (step.type) {
        default: {
            const stage = getStage(step) || FATAL;
            handlers[stage](step);
        }
    }
};

const handleFatalError = (err) => {

    console.error('Fatal error', err);
    // alert("Exception");
};


const onError = (error) => {
    console.log(error);
}
// Get the next step using the FRAuth API
const nextStep = async (step) => {

    step = await FRAuth.next(step).catch(onError);
    console.log(step, "step at end of nextstep");
    await handleStep(step);
};

window.onload = function () {
    step = JSON.parse(sessionStorage.getItem('PasswordCallback'));
    nextStep(step);
}

//nextStep();




