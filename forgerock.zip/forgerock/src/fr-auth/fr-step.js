import createCallback from './callbacks/factory.js';
import { StepType } from './enums.js';

/*
 * @forgerock/javascript-sdk
 *
 * fr-step.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a single step of an authentication tree.
 */
class FRStep {
    /**
     * @param payload The raw payload returned by OpenAM
     * @param callbackFactory A function that returns am implementation of FRCallback
     */
    constructor(payload, callbackFactory) {
        this.payload = payload;
        /**
         * The type of step.
         */
        this.type = StepType.Step;
        /**
         * The callbacks contained in this step.
         */
        this.callbacks = [];
        if (payload.callbacks) {
            this.callbacks = this.convertCallbacks(payload.callbacks, callbackFactory);
        }
    }
    /**
     * Gets the first callback of the specified type in this step.
     *
     * @param type The type of callback to find.
     */
    getCallbackOfType(type) {
        const callbacks = this.getCallbacksOfType(type);
        if (callbacks.length !== 1) {
            throw new Error(`Expected 1 callback of type "${type}", but found ${callbacks.length}`);
        }
        return callbacks[0];
    }
    /**
     * Gets all callbacks of the specified type in this step.
     *
     * @param type The type of callback to find.
     */
    getCallbacksOfType(type) {
        return this.callbacks.filter((x) => x.getType() === type);
    }
    /**
     * Sets the value of the first callback of the specified type in this step.
     *
     * @param type The type of callback to find.
     * @param value The value to set for the callback.
     */
    setCallbackValue(type, value) {
        const callbacks = this.getCallbacksOfType(type);
        if (callbacks.length !== 1) {
            throw new Error(`Expected 1 callback of type "${type}", but found ${callbacks.length}`);
        }
        callbacks[0].setInputValue(value);
    }
    /**
     * Gets the step's description.
     */
    getDescription() {
        return this.payload.description;
    }
    /**
     * Gets the step's header.
     */
    getHeader() {
        return this.payload.header;
    }
    /**
     * Gets the step's stage.
     */
    getStage() {
        return this.payload.stage;
    }
    convertCallbacks(callbacks, callbackFactory) {
        const converted = callbacks.map((x) => {
            // This gives preference to the provided factory and falls back to our default implementation
            return (callbackFactory || createCallback)(x) || createCallback(x);
        });
        return converted;
    }
}

export { FRStep as default };
