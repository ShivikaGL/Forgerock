import { StepType } from './enums.js';

/*
 * @forgerock/javascript-sdk
 *
 * fr-login-success.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
class FRLoginSuccess {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        this.payload = payload;
        /**
         * The type of step.
         */
        this.type = StepType.LoginSuccess;
    }
    /**
     * Gets the step's realm.
     */
    getRealm() {
        return this.payload.realm;
    }
    /**
     * Gets the step's session token.
     */
    getSessionToken() {
        return this.payload.tokenId;
    }
    /**
     * Gets the step's success URL.
     */
    getSuccessUrl() {
        return this.payload.successUrl;
    }
}

export { FRLoginSuccess as default };
