import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * kba-create-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect KBA-style security questions and answers.
 */
class KbaCreateCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the callback prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Gets the callback's list of pre-defined security questions.
     */
    getPredefinedQuestions() {
        return this.getOutputByName('predefinedQuestions', []);
    }
    /**
     * Sets the callback's security question.
     */
    setQuestion(question) {
        this.setValue('question', question);
    }
    /**
     * Sets the callback's security question answer.
     */
    setAnswer(answer) {
        this.setValue('answer', answer);
    }
    setValue(type, value) {
        if (!this.payload.input) {
            throw new Error('KBA payload is missing input');
        }
        const input = this.payload.input.find((x) => x.name.endsWith(type));
        if (!input) {
            throw new Error(`No input has name ending in "${type}"`);
        }
        input.value = value;
    }
}

export { KbaCreateCallback as default };
