import TextOutputCallback from './text-output-callback.js';

/*
 * @forgerock/javascript-sdk
 *
 * suspended-text-output-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to display a message.
 */
class SuspendedTextOutputCallback extends TextOutputCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
}

export { SuspendedTextOutputCallback as default };
