import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * choice-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect an answer to a choice.
 */
class ChoiceCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the choice's prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Gets the choice's default answer.
     */
    getDefaultChoice() {
        return this.getOutputByName('defaultChoice', 0);
    }
    /**
     * Gets the choice's possible answers.
     */
    getChoices() {
        return this.getOutputByName('choices', []);
    }
    /**
     * Sets the choice's answer by index position.
     */
    setChoiceIndex(index) {
        const length = this.getChoices().length;
        if (index < 0 || index > length - 1) {
            throw new Error(`${index} is out of bounds`);
        }
        this.setInputValue(index);
    }
    /**
     * Sets the choice's answer by value.
     */
    setChoiceValue(value) {
        const index = this.getChoices().indexOf(value);
        if (index === -1) {
            throw new Error(`"${value}" is not a valid choice`);
        }
        this.setInputValue(index);
    }
}

export { ChoiceCallback as default };
