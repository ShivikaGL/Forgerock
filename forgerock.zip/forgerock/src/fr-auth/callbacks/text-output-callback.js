import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * text-output-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to display a message.
 */
class TextOutputCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the message content.
     */
    getMessage() {
        return this.getOutputByName('message', '');
    }
    /**
     * Gets the message type.
     */
    getMessageType() {
        return this.getOutputByName('messageType', '');
    }
}

export { TextOutputCallback as default };
