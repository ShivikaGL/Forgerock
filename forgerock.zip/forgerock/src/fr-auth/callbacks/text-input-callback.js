import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * text-input-callback.ts
 *
 * Copyright (c) 2022 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to retrieve input from the user.
 */
class TextInputCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the callback's prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Sets the callback's input value.
     */
    setInput(input) {
        this.setInputValue(input);
    }
}

export { TextInputCallback as default };
