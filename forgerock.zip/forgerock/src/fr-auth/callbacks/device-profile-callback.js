import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * device-profile-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect device profile data.
 */
class DeviceProfileCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the callback's data.
     */
    getMessage() {
        return this.getOutputByName('message', '');
    }
    /**
     * Does callback require metadata?
     */
    isMetadataRequired() {
        return this.getOutputByName('metadata', false);
    }
    /**
     * Does callback require location data?
     */
    isLocationRequired() {
        return this.getOutputByName('location', false);
    }
    /**
     * Sets the profile.
     */
    setProfile(profile) {
        this.setInputValue(JSON.stringify(profile));
    }
}

export { DeviceProfileCallback as default };
