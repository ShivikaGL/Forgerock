import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * confirmation-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect a confirmation to a message.
 */
class ConfirmationCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the index position of the confirmation's default answer.
     */
    getDefaultOption() {
        return Number(this.getOutputByName('defaultOption', 0));
    }
    /**
     * Gets the confirmation's message type.
     */
    getMessageType() {
        return Number(this.getOutputByName('messageType', 0));
    }
    /**
     * Gets the confirmation's possible answers.
     */
    getOptions() {
        return this.getOutputByName('options', []);
    }
    /**
     * Gets the confirmation's option type.
     */
    getOptionType() {
        return Number(this.getOutputByName('optionType', 0));
    }
    /**
     * Gets the confirmation's prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Set option index.
     */
    setOptionIndex(index) {
        if (index !== 0 && index !== 1) {
            throw new Error(`"${index}" is not a valid choice`);
        }
        this.setInputValue(index);
    }
    /**
     * Set option value.
     */
    setOptionValue(value) {
        const index = this.getOptions().indexOf(value);
        if (index === -1) {
            throw new Error(`"${value}" is not a valid choice`);
        }
        this.setInputValue(index);
    }
}

export { ConfirmationCallback as default };
