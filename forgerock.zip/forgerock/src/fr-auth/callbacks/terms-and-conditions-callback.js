import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * terms-and-conditions-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect acceptance of terms and conditions.
 */
class TermsAndConditionsCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the terms and conditions content.
     */
    getTerms() {
        return this.getOutputByName('terms', '');
    }
    /**
     * Gets the version of the terms and conditions.
     */
    getVersion() {
        return this.getOutputByName('version', '');
    }
    /**
     * Gets the date of the terms and conditions.
     */
    getCreateDate() {
        const date = this.getOutputByName('createDate', '');
        return new Date(date);
    }
    /**
     * Sets the callback's acceptance.
     */
    setAccepted(accepted = true) {
        this.setInputValue(accepted);
    }
}

export { TermsAndConditionsCallback as default };
