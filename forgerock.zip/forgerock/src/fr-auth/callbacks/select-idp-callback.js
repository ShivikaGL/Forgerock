import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * select-idp-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect an answer to a choice.
 */
class SelectIdPCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the available providers.
     */
    getProviders() {
        return this.getOutputByName('providers', []);
    }
    /**
     * Sets the provider by name.
     */
    setProvider(value) {
        const item = this.getProviders().find((item) => item.provider === value);
        if (!item) {
            throw new Error(`"${value}" is not a valid choice`);
        }
        this.setInputValue(item.provider);
    }
}

export { SelectIdPCallback as default };
