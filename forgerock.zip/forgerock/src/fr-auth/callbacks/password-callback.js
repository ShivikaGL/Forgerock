import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * password-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect a password.
 */
class PasswordCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the callback's failed policies.
     */
    getFailedPolicies() {
        return this.getOutputByName('failedPolicies', []);
    }
    /**
     * Gets the callback's applicable policies.
     */
    getPolicies() {
        return this.getOutputByName('policies', []);
    }
    /**
     * Gets the callback's prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Sets the password.
     */
    setPassword(password) {
        this.setInputValue(password);
    }
}

export { PasswordCallback as default };
