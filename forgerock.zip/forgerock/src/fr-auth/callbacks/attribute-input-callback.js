import FRCallback from './index.js';

/*
 * @forgerock/javascript-sdk
 *
 * attribute-input-callback.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Represents a callback used to collect attributes.
 *
 * @typeparam T Maps to StringAttributeInputCallback, NumberAttributeInputCallback and
 *     BooleanAttributeInputCallback, respectively
 */
class AttributeInputCallback extends FRCallback {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        super(payload);
        this.payload = payload;
    }
    /**
     * Gets the attribute name.
     */
    getName() {
        return this.getOutputByName('name', '');
    }
    /**
     * Gets the attribute prompt.
     */
    getPrompt() {
        return this.getOutputByName('prompt', '');
    }
    /**
     * Gets whether the attribute is required.
     */
    isRequired() {
        return this.getOutputByName('required', false);
    }
    /**
     * Gets the callback's failed policies.
     */
    getFailedPolicies() {
        const failedPolicies = this.getOutputByName('failedPolicies', []);
        try {
            return failedPolicies.map((v) => JSON.parse(v));
        }
        catch (err) {
            throw new Error('Unable to parse "failed policies" from the ForgeRock server. The JSON within `AttributeInputCallback` was either malformed or missing.');
        }
    }
    /**
     * Gets the callback's applicable policies.
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    getPolicies() {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return this.getOutputByName('policies', {});
    }
    /**
     * Set if validating value only.
     */
    setValidateOnly(value) {
        this.setInputValue(value, /validateOnly/);
    }
    /**
     * Sets the attribute's value.
     */
    setValue(value) {
        this.setInputValue(value);
    }
}

export { AttributeInputCallback as default };
