import FRPolicy from '../fr-policy/index.js';
import { StepType } from './enums.js';

/*
 * @forgerock/javascript-sdk
 *
 * fr-login-failure.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
class FRLoginFailure {
    /**
     * @param payload The raw payload returned by OpenAM
     */
    constructor(payload) {
        this.payload = payload;
        /**
         * The type of step.
         */
        this.type = StepType.LoginFailure;
    }
    /**
     * Gets the error code.
     */
    getCode() {
        return Number(this.payload.code);
    }
    /**
     * Gets the failure details.
     */
    getDetail() {
        return this.payload.detail;
    }
    /**
     * Gets the failure message.
     */
    getMessage() {
        return this.payload.message;
    }
    /**
     * Gets processed failure message.
     */
    getProcessedMessage(messageCreator) {
        return FRPolicy.parseErrors(this.payload, messageCreator);
    }
    /**
     * Gets the failure reason.
     */
    getReason() {
        return this.payload.reason;
    }
}

export { FRLoginFailure as default };
