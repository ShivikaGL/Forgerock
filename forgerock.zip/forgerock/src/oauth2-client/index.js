import { ActionTypes } from '../config/enums.js';
import Config from '../config/index.js';
import TokenStorage from '../token-storage/index.js';
import { isOkOr4xx } from '../util/http.js';
import PKCE from '../util/pkce.js';
import { withTimeout } from '../util/timeout.js';
import { stringify, getEndpointPath, resolve } from '../util/url.js';
export { ResponseType } from './enums.js';
import middlewareWrapper from '../util/middleware.js';

/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020-2021 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
const allowedErrors = {
    // AM error for consent requirement
    AuthenticationConsentRequired: 'Authentication or consent required',
    // Manual iframe error
    AuthorizationTimeout: 'Authorization timed out',
    // Chromium browser error
    FailedToFetch: 'Failed to fetch',
    // Mozilla browser error
    NetworkError: 'NetworkError when attempting to fetch resource.',
    // Webkit browser error
    CORSError: 'Cross-origin redirection',
    // prompt=none errors
    InteractionNotAllowed: 'The request requires some interaction that is not allowed.',
};
/**
 * OAuth 2.0 client.
 */
class OAuth2Client {
    static async createAuthorizeUrl(options) {
        const { clientId, middleware, redirectUri, scope } = Config.get(options);
        const requestParams = {
            ...options.query,
            client_id: clientId,
            redirect_uri: redirectUri,
            response_type: options.responseType,
            scope,
            state: options.state,
            ...(options.prompt ? { prompt: options.prompt } : {}),
        };
        if (options.verifier) {
            const challenge = await PKCE.createChallenge(options.verifier);
            requestParams.code_challenge = challenge;
            requestParams.code_challenge_method = 'S256';
        }
        const runMiddleware = middlewareWrapper({
            url: new URL(this.getUrl('authorize', requestParams, options)),
            init: {},
        }, { type: ActionTypes.Authorize });
        const { url } = runMiddleware(middleware);
        return url.toString();
    }
    /**
     * Calls the authorize URL with an iframe. If successful,
     * it returns the callback URL with authentication code,
     * optionally using PKCE.
     * Method renamed in v3.
     * Original Name: getAuthorizeUrl
     * New Name: getAuthCodeByIframe
     */
    static async getAuthCodeByIframe(options) {
        const url = await this.createAuthorizeUrl({ ...options, prompt: 'none' });
        const { serverConfig } = Config.get(options);
        return new Promise((resolve, reject) => {
            const iframe = document.createElement('iframe');
            // Define these here to avoid linter warnings
            const noop = () => {
                return;
            };
            let onLoad = noop;
            let cleanUp = noop;
            let timeout = 0;
            cleanUp = () => {
                clearTimeout(timeout);
                iframe.removeEventListener('load', onLoad);
                iframe.remove();
            };
            onLoad = () => {
                if (iframe.contentWindow) {
                    const newHref = iframe.contentWindow.location.href;
                    if (this.containsAuthCode(newHref)) {
                        cleanUp();
                        resolve(newHref);
                    }
                    else if (this.containsAuthError(newHref)) {
                        cleanUp();
                        resolve(newHref);
                    }
                }
            };
            timeout = setTimeout(() => {
                cleanUp();
                reject(new Error(allowedErrors.AuthorizationTimeout));
            }, serverConfig.timeout);
            iframe.style.display = 'none';
            iframe.addEventListener('load', onLoad);
            document.body.appendChild(iframe);
            iframe.src = url;
        });
    }
    /**
     * Exchanges an authorization code for OAuth tokens.
     */
    static async getOAuth2Tokens(options) {
        const { clientId, redirectUri } = Config.get(options);
        const requestParams = {
            client_id: clientId,
            code: options.authorizationCode,
            grant_type: 'authorization_code',
            redirect_uri: redirectUri,
        };
        if (options.verifier) {
            requestParams.code_verifier = options.verifier;
        }
        const body = stringify(requestParams);
        const init = {
            body,
            headers: new Headers({
                'Content-Length': body.length.toString(),
                'Content-Type': 'application/x-www-form-urlencoded',
            }),
            method: 'POST',
        };
        const response = await this.request('accessToken', undefined, false, init, options);
        const responseBody = await this.getBody(response);
        if (response.status !== 200) {
            const message = typeof responseBody === 'string'
                ? `Expected 200, received ${response.status}`
                : this.parseError(responseBody);
            throw new Error(message);
        }
        const responseObject = responseBody;
        if (!responseObject.access_token) {
            throw new Error('Access token not found in response');
        }
        let tokenExpiry = undefined;
        if (responseObject.expires_in) {
            tokenExpiry = Date.now() + responseObject.expires_in * 1000;
        }
        return {
            accessToken: responseObject.access_token,
            idToken: responseObject.id_token,
            refreshToken: responseObject.refresh_token,
            tokenExpiry: tokenExpiry,
        };
    }
    /**
     * Gets OIDC user information.
     */
    static async getUserInfo(options) {
    
        const response = await this.request('userInfo', undefined, true, undefined, options);
        if (response.status !== 200) {
            throw new Error(`Failed to get user info; received ${response.status}`);
        }
        const json = await response.json();
        return json;
    }
    /**
     * Invokes the OIDC end session endpoint.
     */
    static async endSession(options) {
        const tokens = await TokenStorage.get();
        const idToken = tokens && tokens.idToken;
        const query = {};
        if (idToken) {
            query.id_token_hint = idToken;
        }
        const response = await this.request('endSession', query, true, undefined, options);
        if (!isOkOr4xx(response)) {
            throw new Error(`Failed to end session; received ${response.status}`);
        }
        return response;
    }
    /**
     * Immediately revokes the stored access token.
     */
    static async revokeToken(options) {
        const { clientId } = Config.get(options);
        const tokens = await TokenStorage.get();
        const accessToken = tokens && tokens.accessToken;
        const body = {
            client_id: clientId,
        };
        // This is needed to support Token Vault; the SDK may not have the token locally
        if (accessToken) {
            body.token = accessToken;
        }
        const init = {
            body: stringify(body),
            credentials: 'include',
            headers: new Headers({
                'Content-Type': 'application/x-www-form-urlencoded',
            }),
            method: 'POST',
        };
        const response = await this.request('revoke', undefined, false, init, options);
        if (!isOkOr4xx(response)) {
            throw new Error(`Failed to revoke token; received ${response.status}`);
        }
        return response;
    }
    static async request(endpoint, query, includeToken, init, options) {
    
        const { middleware, serverConfig } = Config.get(options);
        const url = this.getUrl(endpoint, query, options);
        const getActionType = (endpoint) => {
            switch (endpoint) {
                case 'accessToken':
                    return ActionTypes.ExchangeToken;
                case 'endSession':
                    return ActionTypes.EndSession;
                case 'revoke':
                    return ActionTypes.RevokeToken;
                default:
                    return ActionTypes.UserInfo;
            }
        };
        init = init || {};
        if (includeToken) {
            const tokens = await TokenStorage.get();
            const accessToken = tokens && tokens.accessToken;
            init.credentials = 'include';
            init.headers = (init.headers || new Headers());
            init.headers.set('Authorization', `Bearer ${accessToken}`);
        }
        const runMiddleware = middlewareWrapper({ url: new URL(url), init }, { type: getActionType(endpoint) });
        const req = runMiddleware(middleware);
        return await withTimeout(fetch(req.url.toString(), req.init), serverConfig.timeout);
    }
    static containsAuthCode(url) {
        return !!url && /code=([^&]+)/.test(url);
    }
    static containsAuthError(url) {
        return !!url && /error=([^&]+)/.test(url);
    }
    static async getBody(response) {
        const contentType = response.headers.get('Content-Type');
        if (contentType && contentType.indexOf('application/json') > -1) {
            return await response.json();
        }
        return await response.text();
    }
    static parseError(json) {
        if (json) {
            if (json.error && json.error_description) {
                return `${json.error}: ${json.error_description}`;
            }
            if (json.code && json.message) {
                return `${json.code}: ${json.message}`;
            }
        }
        return undefined;
    }
    static getUrl(endpoint, query, options) {
        const { realmPath, serverConfig } = Config.get(options);
        const path = getEndpointPath(endpoint, realmPath, serverConfig.paths);
        let url = resolve(serverConfig.baseUrl, path);
        if (query) {
            url += `?${stringify(query)}`;
        }
        return url;
    }
}

export { allowedErrors, OAuth2Client as default };
