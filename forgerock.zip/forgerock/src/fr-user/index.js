import { FRLogger } from '../util/logger.js';
import OAuth2Client from '../oauth2-client/index.js';
import SessionManager from '../session-manager/index.js';
import TokenManager from '../token-manager/index.js';

/*
 * @forgerock/javascript-sdk
 *
 * index.ts
 *
 * Copyright (c) 2020 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * High-level API for logging a user in/out and getting profile information.
 */
class FRUser {
    /**
     * Logs the user in with the specified step handler, acquires OAuth tokens, and retrieves
     * user profile.  **Currently not implemented.**
     *
     * @typeparam T The type of user object expected
     * @param handler The function to invoke when handling authentication steps
     * @param options Configuration overrides
     */
    static async login(handler, options) {
        FRLogger.info(handler, options); // Avoid lint errors
        throw new Error('FRUser.login() not implemented');
    }
    /**
     * Ends the user's session and revokes OAuth tokens.
     *
     * @param options Configuration overrides
     */
    static async logout(options) {
        // Just log any exceptions that are thrown, but don't abandon the flow
        try {
            // Both invalidates the session on the server AND removes browser cookie
            await SessionManager.logout(options);
        }
        catch (error) {
            FRLogger.warn('Session logout was not successful');
        }
        try {
            // Invalidates session on the server tied to the ID Token
            // Needed for Express environment as session logout is unavailable
            await OAuth2Client.endSession(options);
        }
        catch (error) {
            FRLogger.warn('OAuth endSession was not successful');
        }
        try {
            await OAuth2Client.revokeToken(options);
        }
        catch (error) {
            FRLogger.warn('OAuth revokeToken was not successful');
        }
        await TokenManager.deleteTokens();
    }
}

export { FRUser as default };
