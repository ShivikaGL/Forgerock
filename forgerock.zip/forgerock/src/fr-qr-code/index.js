import { CallbackType } from "../auth/enums.js"

/**
 * @class FRQRCode - A utility class for handling QR Code steps
 *
 * Example:
 *
 * ```js
 * const isQRCodeStep = FRQRCode.isQRCodeStep(step);
 * let qrCodeData;
 * if (isQRCodeStep) {
 *   qrCodeData = FRQRCode.getQRCodeData(step);
 * }
 * ```
 */
class FRQRCode {
    /**
     * @method isQRCodeStep - determines if step contains QR Code callbacks
     * @param {FRStep} step - step object from AM response
     * @returns {boolean}
     */
    static isQRCodeStep(step) {
        const hiddenValueCb = step.getCallbacksOfType(
            CallbackType.HiddenValueCallback
        )

        // QR Codes step should have at least one HiddenValueCallback
        if (hiddenValueCb.length === 0) {
            return false
        }
        return !!this.getQRCodeURICb(hiddenValueCb)
    }

    /**
     * @method getQRCodeData - gets the necessary information from the QR Code callbacks
     * @param {FRStep} step - step object from AM response
     * @returns {QRCodeData}
     */
    static getQRCodeData(step) {
        const hiddenValueCb = step.getCallbacksOfType(
            CallbackType.HiddenValueCallback
        )

        // QR Codes step should have at least one HiddenValueCallback
        if (hiddenValueCb.length === 0) {
            throw new Error(
                "QR Code step must contain a HiddenValueCallback. Use `FRQRCode.isQRCodeStep` to guard."
            )
        }
        const qrCodeURICb = this.getQRCodeURICb(hiddenValueCb)
        const outputValue = qrCodeURICb ? qrCodeURICb.getOutputValue("value") : ""
        const qrCodeUse =
            typeof outputValue === "string" && outputValue.includes("otpauth://")
                ? "otp"
                : "push"

        const messageCbs = step.getCallbacksOfType(CallbackType.TextOutputCallback)
        const displayMessageCb = messageCbs.find(cb => {
            const textOutputCallback = cb
            return textOutputCallback.getMessageType() !== "4"
        })

        return {
            message: displayMessageCb ? displayMessageCb.getMessage() : "",
            use: qrCodeUse,
            uri: typeof outputValue === "string" ? outputValue : ""
        }
    }

    static getQRCodeURICb(hiddenValueCbs) {
        // Look for a HiddenValueCallback with an OTP URI
        return hiddenValueCbs.find(cb => {
            const outputValue = cb.getOutputValue("value")

            if (typeof outputValue === "string") {
                return (
                    outputValue?.includes("otpauth://") ||
                    outputValue?.includes("pushauth://")
                )
            }
            return false
        })
    }
}

export default FRQRCode
