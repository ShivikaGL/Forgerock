import Config from '../config/index.js';

class FRLogger {
    static enabled() {
        const { logLevel } = Config.get();
        /*
         * Return an object
         * which satisfies the LogLevelRating type
         * and has a key of the current log level
         * and a value of the log level rating
         */
        const logLevels = {
            none: 0,
            error: 25,
            warn: 50,
            info: 75,
            debug: 100,
        };
        return logLevels[logLevel];
    }
    static info(...msgs) {
        const { logger } = Config.get();
        if (this.enabled() >= 50) {
            if (logger && logger.info) {
                logger.info(...msgs);
            }
            else {
                console.info(...msgs);
            }
        }
    }
    static warn(...msgs) {
        const { logger } = Config.get();
        if (this.enabled() >= 50) {
            if (logger && logger.warn) {
                logger.warn(...msgs);
            }
            else {
                console.warn(...msgs);
            }
        }
    }
    static error(...msgs) {
        const { logger } = Config.get();
        if (this.enabled() >= 25) {
            if (logger && logger.error) {
                logger.error(...msgs);
            }
            else {
                console.error(...msgs);
            }
        }
    }
    static log(...msgs) {
        const { logger } = Config.get();
        if (this.enabled() >= 75) {
            if (logger && logger.log) {
                logger.log(...msgs);
            }
            else {
                console.log(...msgs);
            }
        }
    }
}

export { FRLogger };
