/*
 * @forgerock/javascript-sdk
 *
 * pkce.ts
 *
 * Copyright (c) 2020-2021 ForgeRock. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 */
/**
 * Helper class for generating verifier, challenge and state strings used for
 * Proof Key for Code Exchange (PKCE).
 */
class PKCE {
    /**
     * Creates a random state.
     */
    static createState() {
        return this.createRandomString(16);
    }
    /**
     * Creates a random verifier.
     */
    static createVerifier() {
        return this.createRandomString(32);
    }
    /**
     * Creates a SHA-256 hash of the verifier.
     *
     * @param verifier The verifier to hash
     */
    static async createChallenge(verifier) {
        const sha256 = await this.sha256(verifier);
        const challenge = this.base64UrlEncode(sha256);
        return challenge;
    }
    /**
     * Creates a base64 encoded, URL-friendly version of the specified array.
     *
     * @param array The array of numbers to encode
     */
    static base64UrlEncode(array) {
        const numbers = Array.prototype.slice.call(array);
        const ascii = btoa(String.fromCharCode.apply(null, numbers));
        const urlEncoded = ascii.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
        return urlEncoded;
    }
    /**
     * Creates a SHA-256 hash of the specified string.
     *
     * @param value The string to hash
     */
    static async sha256(value) {
        const uint8Array = new TextEncoder().encode(value);
        const hashBuffer = await crypto.subtle.digest('SHA-256', uint8Array);
        const hashArray = new Uint8Array(hashBuffer);
        return hashArray;
    }
    /**
     * Creates a random string.
     *
     * @param size The number for entropy (default: 32)
     */
    static createRandomString(num = 32) {
        const random = new Uint8Array(num);
        crypto.getRandomValues(random);
        return btoa(random.join('')).replace(/[^a-zA-Z0-9]+/, '');
    }
}

export { PKCE as default };
